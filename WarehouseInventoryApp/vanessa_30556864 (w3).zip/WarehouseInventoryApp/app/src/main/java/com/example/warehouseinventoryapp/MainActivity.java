package com.example.warehouseinventoryapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

public class MainActivity extends AppCompatActivity {

    EditText name;
    EditText quantity;
    EditText cost;
    EditText description;
    ToggleButton frozen;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        name = findViewById(R.id.nameInput);
        quantity = findViewById(R.id.quantityInput);
        cost = findViewById(R.id.costInput);
        description = findViewById(R.id.descriptionInput);
        frozen = findViewById(R.id.toggleButton);

    }
    @Override
    protected void onStart() {
        super.onStart();
        restoreSharedPreferences();
        quantity.setText("0");
        cost.setText("0.0");
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
    }

    @Override
    protected void onRestoreInstanceState(Bundle inState) {
        super.onRestoreInstanceState(inState);
    }

    public void clearItem(View view) {
        name.setText("");
        quantity.setText("");
        cost.setText("");
        description.setText("");
        frozen.setChecked(false);

        saveSharedPreferences();
    }

    public void addItem(View view) {
        String item = name.getText().toString();
        Toast addMessage = Toast.makeText(this,"New item (" + item + ") has been added", Toast.LENGTH_SHORT);
        addMessage.show();

        saveSharedPreferences();
    }

    private void saveSharedPreferences() {
        SharedPreferences myData = getPreferences(0);
        SharedPreferences.Editor myEditor = myData.edit();
        myEditor.putString("name", name.getText().toString());
        myEditor.putString("quantity", quantity.getText().toString());
        myEditor.putString("cost", cost.getText().toString());
        myEditor.putString("description", description.getText().toString());
        myEditor.putBoolean("frozen", frozen.isChecked());
        myEditor.commit();
    }

    private void restoreSharedPreferences() {
        SharedPreferences myData = getPreferences(0);
        name.setText(myData.getString("name", ""));
        quantity.setText(myData.getString("quantity", "0"));
        cost.setText(myData.getString("cost", "0.0"));
        description.setText(myData.getString("description", ""));
        frozen.setChecked(myData.getBoolean("frozen", false));
    }
}
