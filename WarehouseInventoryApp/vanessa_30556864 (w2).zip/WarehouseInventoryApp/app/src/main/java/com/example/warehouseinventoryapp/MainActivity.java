package com.example.warehouseinventoryapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

public class MainActivity extends AppCompatActivity {

    EditText name;
    EditText quantity;
    EditText cost;
    EditText description;
    ToggleButton frozen;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        name = findViewById(R.id.nameInput);
        quantity = findViewById(R.id.quantityInput);
        cost = findViewById(R.id.costInput);
        description = findViewById(R.id.descriptionInput);
        frozen = findViewById(R.id.toggleButton);

    }

    public void clearItem(View view) {
        name.setText("");
        quantity.setText("");
        cost.setText("");
        description.setText("");
        frozen.setChecked(false);

    }

    public void addItem(View view) {
        String item = name.getText().toString();
        Toast addMessage = Toast.makeText(this,"New item (" + item + ") has been added", Toast.LENGTH_SHORT);
        addMessage.show();
    }
}
