package com.example.warehouseinventoryapp;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.StringTokenizer;

public class MyRecyclerViewAdapter extends RecyclerView.Adapter<MyRecyclerViewAdapter.ViewHolder> {
    ArrayList<String> itemArray;

    public MyRecyclerViewAdapter(ArrayList<String> data) {
        itemArray = data;
    }

    @NonNull
    @Override
    public MyRecyclerViewAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.card_view, parent, false);
        ViewHolder viewHolder = new ViewHolder(v);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull MyRecyclerViewAdapter.ViewHolder holder, int position) {
        StringTokenizer sT = new StringTokenizer(itemArray.get(position), ";");
        String name = sT.nextToken();
        String quantity = sT.nextToken();
        String cost = sT.nextToken();
        String description = sT.nextToken();
        String frozen = sT.nextToken();

        holder.itemName.setText(name);
        holder.itemQuantity.setText(quantity);
        holder.itemCost.setText(cost);
        holder.itemDescription.setText(description);
        holder.itemFrozen.setText(frozen);
    }

    @Override
    public int getItemCount() {
        return itemArray.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        public View itemView;
        public TextView itemName;
        public TextView itemQuantity;
        public TextView itemCost;
        public TextView itemDescription;
        public TextView itemFrozen;

        public ViewHolder(View itemView) {
            super(itemView);
            this.itemView = itemView;
            itemName = itemView.findViewById(R.id.item_name);
            itemQuantity = itemView.findViewById(R.id.item_quantity);
            itemCost = itemView.findViewById(R.id.item_cost);
            itemDescription = itemView.findViewById(R.id.item_description);
            itemFrozen = itemView.findViewById(R.id.item_frozen);

        }
    }
}
